declare module '*.jpeg';
declare module '*.png';
declare module '*.jpg';
