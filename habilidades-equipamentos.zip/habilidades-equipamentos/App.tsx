import React, {useState, useEffect} from "react";
import { View , Text, Image, TouchableOpacity, TextInput, FlatList } from "react-native";
import { styles } from "./styles";
import SkillCircle from "./png-transparent-d-d-dice-circle-dice-d20-emblem-dnd-dungeons-and-dragons-thumbnail.png";

interface SkillData{
  id: string;
  name: string;
}

const App = () => {
  const[newSkill,setNewSkill] = useState('');
  const[skilladd,setskill] = useState<SkillData[]>([]);
  const[greetings , setGreetings] = useState<string>('');

  useEffect(() =>{
    const currentHour = new Date().getHours();
        if (currentHour < 12){
            setGreetings('GoodMorning')
        } else if(currentHour >= 12 && currentHour < 18){
            setGreetings('Good Afternoon')
        } else {
            setGreetings('Good Evening')
        }
  },[]);

  function handleAddNewSkill(){
    const data = {
      id: String(new Date().getTime()),
      name: newSkill
    }
    setskill(oldSkill =>[...oldSkill ,data])
  }

  return (
  <View style={styles.container} >
    <Text style={styles.title}>god, black</Text>
    <Text style={styles.greetings}>
        {greetings}
    </Text>
    <TextInput
        style={styles.input}
        onChangeText={setNewSkill}
        placeholder="new Skill"

    />
    <TouchableOpacity style={styles.button}
    onPress={handleAddNewSkill}
    >
      <Text>Add</Text>
    </TouchableOpacity>
      
    
    <TouchableOpacity onPress={()=> console.log('janaelson')}>
        <Image source={SkillCircle} style={styles.image}/>
    </TouchableOpacity>
    <FlatList 
        data={skilladd}
        keyExtractor={item => item.id}
        renderItem={({item}) =>{
          return <View style={styles.buttonSkill}>
              <Image source={SkillCircle} style={styles.image}/>
              <Text style={styles.textSkill}>Skill {item.name} {item.id}</Text>
          </View>

        }}
    
    />

  </View >
)};

export default App;